# ReconWizard Report

Target: example.com
Generated: 20250812-145341 UTC
IP: 96.7.128.198
A records: 96.7.128.198, 96.7.128.175, 23.215.0.138, 23.215.0.136, 23.192.228.84, 23.192.228.80

## DNS full

```
{'A': ['96.7.128.198', '96.7.128.175', '23.215.0.138', '23.215.0.136', '23.192.228.84', '23.192.228.80'], 'AAAA': ['2600:1406:bc00:53::b81e:94ce', '2600:1408:ec00:36::1736:7f24', '2600:1408:ec00:36::1736:7f31', '2600:1406:3a00:21::173e:2e65', '2600:1406:3a00:21::173e:2e66', '2600:1406:bc00:53::b81e:94c8'], 'MX': ['0 .'], 'NS': ['a.iana-servers.net.', 'b.iana-servers.net.'], 'TXT': ['"v=spf1 -all"', '"_k2n1y4vw3qtb4skdx9e7dxt97qrmmq9"']}
```

## HTTP Probe

Status Code: 200

### Headers

```
{'Accept-Ranges': 'bytes', 'Content-Type': 'text/html', 'ETag': '"84238dfc8092e5d9c0dac8ef93371a07:1736799080.121134"', 'Last-Modified': 'Mon, 13 Jan 2025 20:11:20 GMT', 'Vary': 'Accept-Encoding', 'Content-Encoding': 'gzip', 'Content-Length': '648', 'Cache-Control': 'max-age=3265', 'Date': 'Tue, 12 Aug 2025 14:53:57 GMT', 'Connection': 'keep-alive'}
```

Favicon SHA256: None