# Отчёт по разведке: example.com

Время: 20250815-125832 UTC

## DNS Records
```json
{'A': ['23.192.228.80', '23.192.228.84', '23.215.0.136', '23.215.0.138', '96.7.128.175', '96.7.128.198'], 'AAAA': ['2600:1408:ec00:36::1736:7f24', '2600:1408:ec00:36::1736:7f31', '2600:1406:3a00:21::173e:2e65', '2600:1406:3a00:21::173e:2e66', '2600:1406:bc00:53::b81e:94c8', '2600:1406:bc00:53::b81e:94ce'], 'MX': ['0 .'], 'NS': ['a.iana-servers.net.', 'b.iana-servers.net.'], 'TXT': ['"_k2n1y4vw3qtb4skdx9e7dxt97qrmmq9"', '"v=spf1 -all"']}
```

## GeoIP Info
```json
{'ip': '23.215.0.136', 'country': 'United States', 'region': 'Virginia', 'city': 'Ashburn', 'isp': 'Akamai International B.V.', 'organization': 'Akamai Technologies, Inc.', 'latitude': 39.0469, 'longitude': -77.4903}
```

## HTTP Info
```json
{'status_code': 200, 'final_url': 'http://example.com/', 'headers': {'Accept-Ranges': 'bytes', 'Content-Type': 'text/html', 'ETag': '"84238dfc8092e5d9c0dac8ef93371a07:1736799080.121134"', 'Last-Modified': 'Mon, 13 Jan 2025 20:11:20 GMT', 'Vary': 'Accept-Encoding', 'Content-Encoding': 'gzip', 'Content-Length': '648', 'Cache-Control': 'max-age=2584', 'Date': 'Fri, 15 Aug 2025 12:58:33 GMT', 'Connection': 'keep-alive'}, 'key_headers': {'server': None, 'x_powered_by': None, 'content_type': 'text/html', 'content_security_policy': None, 'strict_transport_security': None, 'x_frame_options': None, 'x_content_type_options': None, 'referrer_policy': None, 'cache_control': 'max-age=2584'}, 'cookies': [], 'favicon_hash': None}
```

## Open Ports
```json
{'open_ports': [{'port': '80', 'protocol': 'tcp', 'service': 'http', 'product': None, 'version': None}, {'port': '443', 'protocol': 'tcp', 'service': 'https', 'product': None, 'version': None}]}
```

## OSINT Profile
```json
{'ssl_subdomains': {'subdomains': ['*.example.com\nexample.com', '*.example.com\nexample.com\nm.example.com\nwww.example.com', 'AS207960 Test Intermediate - example.com', 'dev.example.com\nexample.com\nproducts.example.com\nsupport.example.com\nwww.example.com', 'example.com\nm.testexample.com\nwww.example.com', 'example.com\nuser@example.com', 'example.com\nwww.example.com', 'subjectname@example.com']}, 'github_search': {'error': 'GitHub API status 401'}, 'hibp': {'hibp': 'Check example.com on https://haveibeenpwned.com'}}
```

## WHOIS Info
```json
{'domain': 'EXAMPLE.COM', 'registrar': 'RESERVED-Internet Assigned Numbers Authority', 'status': ['clientDeleteProhibited https://icann.org/epp#clientDeleteProhibited', 'clientTransferProhibited https://icann.org/epp#clientTransferProhibited', 'clientUpdateProhibited https://icann.org/epp#clientUpdateProhibited'], 'creation_date': '1995-08-14T04:00:00', 'updated_date': '2025-08-14T07:01:39', 'expiration_date': '2026-08-13T04:00:00', 'name_servers': ['a.iana-servers.net', 'b.iana-servers.net'], 'emails': []}
```