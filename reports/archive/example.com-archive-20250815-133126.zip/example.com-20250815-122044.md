# Отчёт по разведке: example.com

Время: 20250815-122044 UTC
IP: 23.192.228.80

## DNS Records
```
{'A': ['23.192.228.84', '23.192.228.80', '96.7.128.198', '96.7.128.175', '23.215.0.138', '23.215.0.136'], 'AAAA': ['2600:1406:3a00:21::173e:2e66', '2600:1406:3a00:21::173e:2e65', '2600:1408:ec00:36::1736:7f31', '2600:1408:ec00:36::1736:7f24', '2600:1406:bc00:53::b81e:94ce', '2600:1406:bc00:53::b81e:94c8'], 'MX': ['0 .'], 'NS': ['a.iana-servers.net.', 'b.iana-servers.net.'], 'TXT': ['"_k2n1y4vw3qtb4skdx9e7dxt97qrmmq9"', '"v=spf1 -all"']}
```

## HTTP Info
Status Code: 200

### Headers
```
{'Accept-Ranges': 'bytes', 'Content-Type': 'text/html', 'ETag': '"84238dfc8092e5d9c0dac8ef93371a07:1736799080.121134"', 'Last-Modified': 'Mon, 13 Jan 2025 20:11:20 GMT', 'Vary': 'Accept-Encoding', 'Content-Encoding': 'gzip', 'Content-Length': '648', 'Cache-Control': 'max-age=369', 'Date': 'Fri, 15 Aug 2025 12:20:44 GMT', 'Connection': 'keep-alive'}
```

Favicon SHA256: None

## WHOIS Info
```
{'domain': 'EXAMPLE.COM', 'registrar': 'RESERVED-Internet Assigned Numbers Authority', 'creation_date': '1995-08-14 04:00:00', 'expiration_date': '2026-08-13 04:00:00', 'name_servers': ['A.IANA-SERVERS.NET', 'B.IANA-SERVERS.NET'], 'emails': None}
```